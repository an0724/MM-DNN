import os
import torch
import torch.nn as nn
import torch.optim as optim
import torchvision.transforms as transforms
from torchvision import datasets, models
from torch.utils.data import DataLoader
from sklearn.metrics import accuracy_score, confusion_matrix
import seaborn as sns
import matplotlib.pyplot as plt
import numpy as np
import time
import pandas as pd


def count_parameters(model):
    """计算模型的总参数量和可训练参数量"""
    total_params = sum(p.numel() for p in model.parameters())
    trainable_params = sum(p.numel() for p in model.parameters() if p.requires_grad)
    return total_params, trainable_params


# 程序开始时间
begin_time = time.time()

# 自定义文件夹路径
output_dir = 'D:/EMG/resnet50/output'  # 替换为实际输出目录
os.makedirs(output_dir, exist_ok=True)  # 创建输出目录（如果不存在）

# 定义超参数
num_classes = 'xx'  # 根据你的数据集类别进行调整
batch_size = 'xx'
num_epochs = 'xx'
learning_rate = 'r'
best_accuracy = 0

# 数据预处理
transform = transforms.Compose([
    transforms.Resize((224, 224)),  # ResNet50 输入尺寸为 224x224
    transforms.ToTensor(),
    transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
])

# 自定义数据集路径
train_dir = "your dir"  # 替换为你的训练数据路径
val_dir = "your dir"  # 替换为你的验证数据路径
train_dataset = datasets.ImageFolder(train_dir, transform)
val_dataset = datasets.ImageFolder(val_dir, transform)
train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True)
val_loader = DataLoader(val_dataset, batch_size=batch_size, shuffle=False)

# 获取类别名称（用于混淆矩阵标签）
class_names = train_dataset.classes

# 加载 ResNet50 模型
model = models.resnet50(pretrained=True)
num_ftrs = model.fc.in_features
model.fc = nn.Linear(num_ftrs, num_classes)  # 修改最后的全连接层

# 计算参数量
total_params, trainable_params = count_parameters(model)
print(f"模型总参数量: {total_params:,}")
print(f"模型可训练参数量: {trainable_params:,}")

# 选择设备
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
model = model.to(device)

# 定义损失函数和优化器
criterion = nn.CrossEntropyLoss()
optimizer = optim.Adam(model.parameters(), lr=learning_rate)

# 使用 CosineAnnealingLR 学习率调度器
scheduler = optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=num_epochs, eta_min=0)

# 用于保存训练过程中的损失和准确率
train_losses = []
val_losses = []
train_accuracies = []
val_accuracies = []

# 存储最后 25 轮的验证准确率
last_25_val_accuracies = []

# 训练模型
for epoch in range(num_epochs):
    model.train()  # 设置模型为训练模式
    running_loss = 0.0
    all_labels = []
    all_preds = []

    # 使用 tqdm 包装训练数据加载器
    for inputs, labels in tqdm(train_loader, desc=f'Epoch {epoch + 1}/{num_epochs}', unit='batch'):
        inputs, labels = inputs.to(device), labels.to(device)

        # 清零梯度
        optimizer.zero_grad()

        # 前向传播
        outputs = model(inputs)
        loss = criterion(outputs, labels)

        # 反向传播和优化
        loss.backward()
        optimizer.step()

        # 统计
        running_loss += loss.item()
        _, preds = torch.max(outputs, 1)
        all_labels.extend(labels.cpu().numpy())
        all_preds.extend(preds.cpu().numpy())

    # 计算训练准确率
    train_accuracy = accuracy_score(all_labels, all_preds)
    train_losses.append(running_loss / len(train_loader))
    train_accuracies.append(train_accuracy)

    # 验证阶段
    model.eval()  # 设置模型为评估模式
    val_running_loss = 0.0
    val_all_labels = []
    val_all_preds = []

    with torch.no_grad():  # 不需要计算梯度
        for val_inputs, val_labels in tqdm(val_loader, desc='Validation', unit='batch'):
            val_inputs, val_labels = val_inputs.to(device), val_labels.to(device)

            val_outputs = model(val_inputs)
            val_loss = criterion(val_outputs, val_labels)

            val_running_loss += val_loss.item()
            _, val_preds = torch.max(val_outputs, 1)
            val_all_labels.extend(val_labels.cpu().numpy())
            val_all_preds.extend(val_preds.cpu().numpy())

    # 计算验证准确率
    val_accuracy = accuracy_score(val_all_labels, val_all_preds)
    val_losses.append(val_running_loss / len(val_loader))
    val_accuracies.append(val_accuracy)

    # 存储最后 25 轮的验证准确率
    last_25_val_accuracies.append(val_accuracy)
    if len(last_25_val_accuracies) > 25:
        last_25_val_accuracies.pop(0)

    # 输出训练和验证信息
    print(f'Epoch [{epoch + 1}/{num_epochs}], '
          f'Train Loss: {train_losses[-1]:.4f}, Train Accuracy: {train_accuracy:.4f}, Val Accuracy: {val_accuracy:.4f}')

    # 保存最佳模型（同时保存该模型对应的混淆矩阵）
    if val_accuracy > best_accuracy:
        best_accuracy = val_accuracy
        best_model_path = os.path.join(output_dir, 'DB6_s1_1_best_model.pth')
        torch.save(model.state_dict(), best_model_path)
        print("Best model saved!")

        # 生成最佳模型的混淆矩阵
        cm = confusion_matrix(val_all_labels, val_all_preds)
        plt.figure(figsize=(10, 8))
        sns.heatmap(cm, annot=True, fmt='d', cmap='Blues',
                    xticklabels=class_names,
                    yticklabels=class_names)
        plt.xlabel('Predicted')
        plt.ylabel('True')
        plt.title(f'Confusion Matrix (Best Model, Epoch {epoch + 1}, Acc: {best_accuracy:.4f})')
        plt.tight_layout()
        cm_path = os.path.join(output_dir, 'confusion_matrix_best.png')
        plt.savefig(cm_path)
        plt.close()

    # 调用学习率调度器的 step 方法更新学习率
    scheduler.step()

# 训练结束后生成最终模型的混淆矩阵
model.load_state_dict(torch.load(best_model_path))  # 加载最佳模型
model.eval()
final_val_labels = []
final_val_preds = []
with torch.no_grad():
    for inputs, labels in val_loader:
        inputs, labels = inputs.to(device), labels.to(device)
        outputs = model(inputs)
        _, preds = torch.max(outputs, 1)
        final_val_labels.extend(labels.cpu().numpy())
        final_val_preds.extend(preds.cpu().numpy())

# 计算并保存最终混淆矩阵
final_cm = confusion_matrix(final_val_labels, final_val_preds)
plt.figure(figsize=(10, 8))
sns.heatmap(final_cm, annot=True, fmt='d', cmap='Blues',
            xticklabels=class_names,
            yticklabels=class_names)
plt.xlabel('Predicted')
plt.ylabel('True')
plt.title(f'Final Confusion Matrix (Best Model, Acc: {best_accuracy:.4f})')
plt.tight_layout()
final_cm_path = os.path.join(output_dir, 'confusion_matrix_final.png')
plt.savefig(final_cm_path)
plt.close()

# 计算平均训练和验证准确率
average_train_accuracy = np.mean(train_accuracies)
average_val_accuracy = np.mean(val_accuracies)

print(f'Average Training Accuracy: {average_train_accuracy:.4f}')
print(f'Average Validation Accuracy: {average_val_accuracy:.4f}')

# 计算最后 25 轮的平均验证准确率
average_last_25_val_accuracy = np.mean(last_25_val_accuracies)
print(f'Average Validation Accuracy of the last 25 epochs: {average_last_25_val_accuracy:.4f}')

# 将每轮的训练准确率和验证准确率存储在表格里
rate_data = {'Epoch': range(1, num_epochs + 1),
             'Train Accuracy': train_accuracies,
             'Validation Accuracy': val_accuracies}
rate_df = pd.DataFrame(rate_data)
rate_df.to_excel(os.path.join(output_dir, 'rate1.xlsx'), index=False)

# 绘制训练和验证损失曲线
plt.figure(figsize=(12, 5))
plt.subplot(1, 2, 1)
plt.plot(range(1, num_epochs + 1), train_losses, label='Train Loss', color='blue')
plt.plot(range(1, num_epochs + 1), val_losses, label='Val Loss', color='orange')
plt.xlabel('Epochs')
plt.ylabel('Loss')
plt.title('Training and Validation Loss')
plt.legend()
plt.grid()

# 绘制训练和验证准确率曲线
plt.subplot(1, 2, 2)
plt.plot(range(1, num_epochs + 1), train_accuracies, label='Train Accuracy', color='blue')
plt.plot(range(1, num_epochs + 1), val_accuracies, label='Val Accuracy', color='orange')
plt.xlabel('Epochs')
plt.ylabel('Accuracy')
plt.title('Training and Validation Accuracy')
plt.legend()
plt.grid()

plt.tight_layout()

# 保存图像
plt.savefig(os.path.join(output_dir, 'training_validation_curves.png'))
plt.show()

print("Training complete. Best validation accuracy: {:.4f}".format(best_accuracy))

time.sleep(5)

# 程序结束时间
end_time = time.time()

# 运行时间计算
run_time = round(end_time - begin_time)
hour = run_time // 3600
minute = (run_time - 3600 * hour) // 60
second = run_time - 3600 * hour - 60 * minute

print(f'该程序运行时间：{hour}小时{minute}分钟{second}秒')