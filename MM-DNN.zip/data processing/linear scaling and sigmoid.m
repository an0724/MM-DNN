% 读取 Excel 文件 label1.xlsx 中的表格数据
label1 = readtable('xxxx.xlsx');

% 将表格数据转换为数组
data = table2array(label1);

% 定义 sigmoid 函数
sigmoid = @(x) 1./(1 + exp(-x));

% 计算将数据映射到 [-4, 4] 所需的缩放因子
minVal = min(data(:));
maxVal = max(data(:));
scaleFactor = 8 / (maxVal - minVal);
shiftFactor = -4 - scaleFactor * minVal;

% 进行 sigmoid 归一化处理
normalizedData = sigmoid(scaleFactor * data + shiftFactor);

% 将归一化后的数据重新存储到一个新的表格中
normalizedLabel1 = array2table(normalizedData, 'VariableNames', label1.Properties.VariableNames);

% 将归一化后的表格数据存储到 guiyi1.xlsx 文件中
writetable(normalizedLabel1, 'xxxxxx.xlsx');