% 定义文件的基础名称和后缀
baseName = 'xxxx';
suffix = '.xlsx';
numFiles = xx;

for i = 1:numFiles
    % 构建输入和输出文件名
    inputFileName = [baseName, num2str(i), suffix];
    outputFileName = ['xxxxxx', num2str(i), '.xlsx'];
    
    % 读取 Excel 文件并转换为表格
    tableData = readtable(inputFileName);
    dataMatrix = table2array(tableData);
    
    % 取指数的绝对值
    exponentMatrix = abs(log10(dataMatrix));
    
    % 将结果存储在一个新的表格中
    resultTable = array2table(exponentMatrix, 'VariableNames', tableData.Properties.VariableNames);
    
    % 将结果表格保存为 Excel 文件
    writetable(resultTable, outputFileName);
end