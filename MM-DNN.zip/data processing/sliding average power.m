for file_index = 1:40
    % 1. 读取 Excel 文件，并仅保留前8列数据
    data = xlsread(sprintf('%d.xlsx', file_index));
    data = data(:, 1:8);  % 只保留前8列，舍弃后续列
    
    % 2. 获取前8列的列数（固定为8）
    num_cols = size(data, 2);  % num_cols = 8
    
    % 3. 存储结果的表格：行数根据全部数据调整，列数为8列
    num_rows = size(data, 1);  % 获取全部数据的行数
    result_table = zeros(num_rows - 199, num_cols);  % 行数适配全部数据，避免越界
    for i = 1:(num_rows - 199)  % 确保窗口不超出数据范围
        % 截取当前窗口的行范围（使用全部数据）
        start_row = i;
        end_row = i + 199;  % 窗口固定为200行
        
        % 4. 截取窗口内的前8列数据
        sub_data = data(start_row:end_row, :);
        
        % 5. 计算每列的能量密度（仅前8列）
        for j = 1:num_cols
            energy_density = sum(sub_data(:, j).^2) / size(sub_data, 1);
            result_table(i, j) = energy_density;
        end
    end
    
    % 将前8列的能量密度结果存储到Excel
    result_table = array2table(result_table);
    writetable(result_table, sprintf('pingfang%d.xlsx', file_index));
    fprintf('已处理文件%d：使用全部数据计算前8列能量密度，结果保存至pingfang%d.xlsx\n', file_index, file_index);
endfor file_index = 1:6
    % 1. 读取 Excel 文件，并仅保留前8列数据
    data = xlsread(sprintf('%d.xlsx', file_index));
    data = data(:, 1:8);  % 只保留前8列，舍弃后续列
    
    % 2. 获取前8列的列数（固定为8）
    num_cols = size(data, 2);  % num_cols = 8
    
    % 3. 存储结果的表格：行数根据全部数据调整，列数为8列
    num_rows = size(data, 1);  % 获取全部数据的行数
    result_table = zeros(num_rows - 199, num_cols);  % 行数适配全部数据，避免越界
    
    % 开始循环计算能量密度（使用100%数据）
    % 直接使用全部数据的行数，不再计算90%的行数
    for i = 1:(num_rows - 199)  % 确保窗口不超出数据范围
        % 截取当前窗口的行范围（使用全部数据）
        start_row = i;
        end_row = i + 199;  % 窗口固定为200行
        
        % 4. 截取窗口内的前8列数据
        sub_data = data(start_row:end_row, :);
        
        % 5. 计算每列的能量密度（仅前8列）
        for j = 1:num_cols
            energy_density = sum(sub_data(:, j).^2) / size(sub_data, 1);
            result_table(i, j) = energy_density;
        end
    end
    
    % 将前8列的能量密度结果存储到Excel
    result_table = array2table(result_table);
    writetable(result_table, sprintf('pingfang%d.xlsx', file_index));
    fprintf('已处理文件%d：使用全部数据计算前8列能量密度，结果保存至pingfang%d.xlsx\n', file_index, file_index);
end